/* ========================
  App AgoraDZ - JS (CodePen)
   - stockage local via localStorage
   - posts avec media (dataURL)
   - messages entre associations
   - suivi (follow)
   - PWA: prompt d'installation + enregistrement service worker
   ========================= */

console.clear();

/* ---------- Helpers ---------- */
const $ = id => document.getElementById(id);
const toast = (txt, t=2500) => {
  const el = $('toast'); el.textContent = txt; el.classList.remove('hidden');
  setTimeout(()=>el.classList.add('hidden'), t);
};
const uid = ()=>Date.now().toString(36) + Math.random().toString(36).slice(2,7);

/* ---------- State ---------- */
let state = JSON.parse(localStorage.getItem('agora_state_v1') || '{}');
if(!state.assocs) state = {assocs: [], posts: [], messages: [], following: [], pendingInstallPrompt: null};
saveState();

function saveState(){ localStorage.setItem('agora_state_v1', JSON.stringify(state)); }

/* ---------- UI init ---------- */
const views = document.querySelectorAll('.panel');
const navBtns = document.querySelectorAll('.nav-btn');

function showView(id) {
  views.forEach(v=>v.classList.remove('active'));
  $(id).classList.add('active');
  navBtns.forEach(b=>b.classList.toggle('active', b.dataset.view===id));
}
document.querySelectorAll('.nav-btn').forEach(b=>{
  b.addEventListener('click', ()=> showView(b.dataset.view));
});

/* Install button (PWA prompt) */
let deferredPrompt = null;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  $('btnInstall').style.display = 'inline-block';
});
$('btnInstall').addEventListener('click', async () => {
  if(!deferredPrompt) return toast('Installation non disponible pour l’instant');
  deferredPrompt.prompt();
  const choice = await deferredPrompt.userChoice;
  if(choice.outcome === 'accepted') toast('Application installée ✅');
  deferredPrompt = null; $('btnInstall').style.display = 'none';
});

/* register service worker (works only on HTTPS / GitHub Pages) */
if('serviceWorker' in navigator){
  navigator.serviceWorker.register('service-worker.js').then(()=>console.log('SW registered')).catch(e=>console.warn('SW failed', e));
}

/* ---------- Associations management ---------- */
function renderAssocList() {
  const list = $('assocList');
  list.innerHTML = '';
  const filter = $('search').value?.toLowerCase?.() || '';
  state.assocs.filter(a => !filter || a.name.toLowerCase().includes(filter) || a.wilaya?.toLowerCase().includes(filter))
    .forEach(a => {
      const div = document.createElement('div');
      div.className = 'assoc-card';
      div.innerHTML = `
        <div class="assoc-avatar">${(a.name||'A').slice(0,2).toUpperCase()}</div>
        <div class="assoc-meta">
          <div class="name">${a.name}</div>
          <div class="muted">${a.wilaya || ''} • ${a.phone || ''}</div>
        </div>
      `;
      div.onclick = ()=> openAssocProfile(a.id);
      list.appendChild(div);
    });
  renderFollowing();
  populateSelects();
}

/* register new assoc */
$('saveAssoc').addEventListener('click', async ()=>{
  const name = $('name').value.trim(); if(!name) return toast('Nom requis');
  const a = {
    id: uid(), name,
    email: $('email').value.trim(),
    phone: $('phone').value.trim(),
    wilaya: $('wilaya').value.trim(),
    address: $('address').value.trim(),
    description: $('description').value.trim(),
    logo: null
  };

  // logo file to dataURL
  const file = $('logoFile').files[0];
  if(file){
    a.logo = await fileToDataURL(file);
  }

  state.assocs.unshift(a); saveState();
  renderAssocList();
  toast('Association créée ✅');
  clearAssocForm();
  showView('feedView');
});

/* cancel */
$('cancelAssoc').addEventListener('click', ()=>{ clearAssocForm(); showView('feedView'); });

function clearAssocForm(){
  ['name','email','phone','wilaya','address','description'].forEach(id=>$(id).value='');
  $('logoFile').value = '';
}

/* open profile (simple modal-like view) */
function openAssocProfile(id){
  const a = state.assocs.find(x=>x.id===id);
  if(!a) return;
  // open posts filtered by assoc (simple: show toast and filter feed)
  const filterSelect = $('filterWilaya');
  filterSelect.value = a.wilaya || '';
  toast(`${a.name} — filtre appliqué`);
  renderFeed();
}

/* ---------- Following ---------- */
function renderFollowing(){
  const el = $('followingList');
  el.innerHTML = '';
  state.following.forEach(id=>{
    const a = state.assocs.find(x=>x.id===id);
    if(!a) return;
    const d = document.createElement('div'); d.className='assoc-card';
    d.innerHTML = `<div class="assoc-avatar small">${a.name.slice(0,2).toUpperCase()}</div><div><div class="name">${a.name}</div><div class="muted">${a.wilaya}</div></div>`;
    el.appendChild(d);
  });
}

/* add / remove follow (from feed post card) */
function toggleFollow(assocId){
  if(state.following.includes(assocId)){
    state.following = state.following.filter(x=>x!==assocId);
    toast('Ne plus suivre');
  } else {
    state.following.push(assocId);
    toast('Suivi ajouté');
  }
  saveState(); renderFollowing(); renderFeed();
}

/* ---------- Feed (posts) ---------- */
async function publishPost(){
  const text = $('postText').value.trim();
  const assocId = $('postAssocSelect').value;
  if(!assocId) return toast('Choisis une association émettrice');
  const file = $('postMedia').files[0];
  let media = null;
  if(file){
    // conversion en dataURL (attention aux tailles)
    media = { type: file.type, data: await fileToDataURL(file), name: file.name };
  }

  const post = { id: uid(), assocId, text, media, time: Date.now() };
  state.posts.unshift(post); saveState();
  $('postText').value=''; $('postMedia').value='';
  toast('Activité publiée');
  renderFeed();
}

$('publishBtn').addEventListener('click', publishPost);
$('btnNewPost').addEventListener('click', ()=>{ window.scrollTo({top:0,behavior:'smooth'}); $('postText').focus(); });

function renderFeed(){
  const container = $('feed'); container.innerHTML = '';
  const filterWilaya = $('filterWilaya').value || '';
  const query = $('search').value.trim().toLowerCase();

  state.posts.filter(p => {
    const assoc = state.assocs.find(a=>a.id===p.assocId) || {};
    if(filterWilaya && assoc.wilaya !== filterWilaya) return false;
    if(query && !(assoc.name?.toLowerCase?.().includes(query) || p.text?.toLowerCase?.().includes(query))) return false;
    return true;
  }).forEach(p => {
    const assoc = state.assocs.find(a=>a.id===p.assocId) || {name:'Anonyme',wilaya:''};
    const card = document.createElement('div'); card.className='post';
    card.innerHTML = `
      <div class="meta">
        <div><strong>${assoc.name}</strong> <span class="muted">• ${new Date(p.time).toLocaleString()}</span></div>
        <div>
          <button class="btn" data-assoc="${assoc.id}" onclick="toggleFollow('${assoc.id}')">${state.following.includes(assoc.id)?'Suivi':'+ Suivre'}</button>
        </div>
      </div>
      <p>${escapeHtml(p.text || '')}</p>
      ${p.media ? (p.media.type.startsWith('image') ? `<img src="${p.media.data}" alt="media"/>` : `<video controls src="${p.media.data}"></video>`) : ''}
    `;
    container.appendChild(card);
  });
}

/* ---------- Conversations / Messages ---------- */
function renderConversations(){
  const conv = $('conversations'); conv.innerHTML = '';
  // conversations are simplified: grouped by pair of assocIDs in messages
  const convKeys = Array.from(new Set(state.messages.map(m => m.convId)));
  convKeys.forEach(k=>{
    const msgs = state.messages.filter(m=>m.convId===k);
    const last = msgs[msgs.length-1];
    const div = document.createElement('div'); div.className='assoc-card';
    div.innerHTML = `<div class="assoc-avatar">${last.fromName?.slice(0,2).toUpperCase()}</div><div><div class="name">${last.fromName}</div><div class="muted">${last.text.slice(0,80)}</div></div>`;
    div.onclick = ()=> openConversation(k);
    conv.appendChild(div);
  });
}

function openConversation(convId){
  const chatWindow = $('chatWindow');
  chatWindow.innerHTML = '';
  const msgs = state.messages.filter(m=>m.convId===convId);
  msgs.forEach(m=>{
    const d = document.createElement('div'); d.className='chat-msg ' + (m.fromId === $('chatFrom').value ? 'me' : 'other');
    d.textContent = `${m.fromName}: ${m.text}`;
    chatWindow.appendChild(d);
  });
  chatWindow.scrollTop = chatWindow.scrollHeight;
  $('chatWindow').dataset.conv = convId;
}

$('chatSend').addEventListener('click', ()=>{
  const fromId = $('chatFrom').value;
  const text = $('chatText').value.trim(); if(!text) return;
  const toId = prompt('Envoyer à quelle association (colle l\'ID ou sélectionne) — pour prototype, écrire ID cible:');
  if(!toId) return toast('ID destinataire requis');

  // convId is sorted pair
  const convId = [fromId, toId].sort().join('__');
  const fromName = (state.assocs.find(a=>a.id===fromId)||{}).name || 'Anonyme';
  state.messages.push({id:uid(),convId,fromId,toId,fromName,text,time:Date.now()});
  saveState(); renderConversations(); openConversation(convId);
  $('chatText').value = '';
});

/* ---------- Utilities ---------- */
function fileToDataURL(file){
  return new Promise((res, rej)=>{
    const reader = new FileReader();
    reader.onload = e => res(e.target.result);
    reader.onerror = e => rej(e);
    reader.readAsDataURL(file);
  });
}

function escapeHtml(s=''){ return s.replace?.(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;') || s; }

/* ---------- Populate selects and filters ---------- */
function populateSelects(){
  const sel = $('postAssocSelect'); sel.innerHTML = '<option value="">Choisir une association</option>';
  const fromSel = $('chatFrom'); fromSel.innerHTML = '';
  const wilayaSel = $('filterWilaya'); wilayaSel.innerHTML = '<option value="">Toutes les wilayas</option>';
  const wilayas = new Set();

  state.assocs.forEach(a=>{
    sel.innerHTML += `<option value="${a.id}">${a.name}</option>`;
    fromSel.innerHTML += `<option value="${a.id}">${a.name}</option>`;
    if(a.wilaya) wilayas.add(a.wilaya);
  });

  Array.from(wilayas).sort().forEach(w => wilayaSel.innerHTML += `<option value="${w}">${w}</option>`);
}

/* ---------- Listeners & boot ---------- */
$('search').addEventListener('input', renderFeed);
$('filterWilaya').addEventListener('change', renderFeed);
$('postAssocSelect').addEventListener('change', ()=>$('postText').focus());
$('chatFrom').addEventListener('change', ()=>{ /* placeholder */ });

window.addEventListener('load', ()=>{
  renderAssocList(); renderFeed(); renderConversations(); populateSelects();
});

/* ---------- small demo data if empty ---------- */
if(!state.assocs.length){
  state.assocs.push({
    id: uid(), name: 'YouthImpact (Oran)', email:'youth@or.example', phone:'0550xxxxxx', wilaya:'Oran', address:'Rue A', description:'Bénévolat & événements', logo:null
  });
  state.assocs.push({
    id: uid(), name: 'Solidarité Tlemcen', email:'contact@st.example', phone:'0551xxxxxx', wilaya:'Tlemcen', address:'Av B', description:'Projets sociaux', logo:null
  });
  saveState();
  renderAssocList(); populateSelects();
}

/* ---------- Expose some functions for inline onclick handlers ---------- */
window.toggleFollow = toggleFollow;
window.openAssocProfile = openAssocProfile;